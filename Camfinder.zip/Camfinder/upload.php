<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $targetDirectory = 'uploads/'; // Specify the directory where you want to store the images
    $targetFile = $targetDirectory . basename($_FILES['image']['name']);
    $uploadSuccess = move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);

    if ($uploadSuccess) {
        echo 'Image uploaded successfully!';
    } else {
        echo 'Image upload failed!';
    }
}
?>

